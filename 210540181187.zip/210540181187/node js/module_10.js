/*10) Consider a text file that contains emp information - id, name, dept, designation, salary
Consider another text file - resignedEmp.txt - that already contains following info about resigned
employees - empid, name, date-of-resignation
For a hardcoded empid, read from emp.txt, extract details and append these details to resignedEmp.txt
*/

var fs = require("fs")
//fs.writeFile("emp.txt" , "empid:name:dept:designation:salary"+'\n' , function(){})
fs.appendFile("emp.txt" , "101:chandana:IT:developer:50000"+'\n' , function(){})
fs.appendFile("emp.txt" , "102:amanvyas:IT:developer:75000"+'\n' , function(){})
fs.appendFile("emp.txt" , "103:nikhil:IT:developer:60000"+'\n' , function(){})

//fs.writeFile("resignedEmp.txt" , "empid:name:date-of-resignation"+'\n' , function(){})
fs.appendFile("resignedEmp.txt" , "105:shivani:12-may-2022"+'\n' , function(){})
fs.appendFile("resignedEmp.txt" , "106:dharya:18-nov-2021"+'\n' , function(){})
fs.appendFile("resignedEmp.txt" , "107:avinash:25-oct-2022"+'\n' , function(){})

fs.readFile("emp.txt" , function(err,data){
    if(err)
    console.log(err)
    
    else
    v=data.toString();
    v=v.split("\n");
    for(i=0; i<3;i++)
    {
        a=v[i].split(":")
        var n = a[0]+":"+a[1]+":"
        fs.appendFile("resignedEmp.txt" , n.toString()+":"+"21-may-2022" , function(){})
    }
       // fs.appendFile("resignedEmp.txt" , n.toString()+":"+"21-may-2022" , function(){})
       
       
    });