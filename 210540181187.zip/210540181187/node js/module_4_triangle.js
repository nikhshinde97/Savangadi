/*4) Create 3 user defined modules that deal with shapes: circle.js, rectangle.js, triangle.js
 Circle.js has functions like : calcArea(radius), calcCircumference(radius), calcDiameter(radius)
 Rectangle.js – calcArea(length, breadth), calcPerimeter(length, breadth)
 Triangle.js – isEquilateral(side1, side2, side3), calcPerimeter()
Make use of Math predefined core object. Create a client application that invokes each of these methods
*/

//TRIANGLE

exports.isEquilateral = function(side1, side2, side3){

    if(side1==side2 && side2==side3)
    {
        console.log("it is an equilateral triangle");
    }

    else
    {
        console.log("it is not an equilateral triangle");
    }
}

exports.calcPerimeter = function(side1, side2, side3){

    var perimeter = side1+side2+side3
    console.log("perimeter of triangle is: " + perimeter)
}