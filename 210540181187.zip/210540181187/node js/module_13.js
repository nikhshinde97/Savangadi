/*13) Write a browser based app that receives welcome.html each time a request is sent.
*/

var http = require("http");
//var url = require("url")
var fs = require("fs")



var server = http.createServer(function(req, res){

    if( req.method=='GET' && req.url=='/')
    {
    res.writeHead(200,{"content-Type" : "text/html"})
    fs.createReadStream('./welcome.html').pipe(res)
    }
})

    server.listen("3002", "localhost")
    



