/*7) File handling: Assume I have a file emp.txt that contains employee data in fixed record size the
following format:
1001:Harry :Sales :23000
1002:Sarita :Accounts :20000
1003:Monika:TechSupport:35000
Read the file. Display sum of salary of all employees
*/

var fs = require("fs");

fs.writeFile("emp3.txt" , "1001:Harry :Sales :23000"+'\n' , function(err){});
fs.appendFile("emp3.txt" , "1002:Sarita :Accounts :20000"+'\n' , function(err){});
fs.appendFile("emp3.txt" , "1003:Monika:TechSupport:35000" , function(err){});



var r = fs.readFile("emp3.txt", function(err, data){
    if(err)
    console.error("err")
    else
    sum=0;
    v = data.toString()
    v = v.split("\n");
    for(i=0; i<3; i++)
    {
        a=v[i].split(":");
        sum=sum+parseInt(a[3])
    } 
   console.log("sum of salary is: "+ sum)
});

