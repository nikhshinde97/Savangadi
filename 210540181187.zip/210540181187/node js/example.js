var http = require("http");


/*function process_request(res, req){
    console.log(req.url);
if( req.method=='GET' && req.url=='/')
{
    fs.readFile("welcome.html" , function(err, data){
        res.writeHead(200,{"content- Type" : "text/html"})
        res.write(data)
        res.end
    })
}
}*/

/*else if(req.method == 'GET' && req.url.substring(0,8) == '/process'){
    var q = url.parse(req.url, true);
    var qdata = q.query;
    var uname = qdata.uname;
    fs.readFile("welcome.html", function(err, data){
    if(err) {
        res.writeHead(404, {'Content-Type': 'text/html'});
        res.end("404 Not Found");
     }  
      res.writeHead(200, {'Content-Type': 'text/html'});
      res.write(data);
      res.end();
  });
}
}*/