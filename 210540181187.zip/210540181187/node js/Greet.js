exports.greet = function(name){
    var d1= new Date();
    var hour= d1.getHours();
    
    if(hour<11)
    {
    return("Good Morning " + name);
    }
    
    else if(hour<16)
    {
    return("Good Afternoon" +name);
    }
    
    else{
    return("Good Evening " + name);
    }
    }