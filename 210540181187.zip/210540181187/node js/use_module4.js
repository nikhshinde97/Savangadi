var circle = require("./module_4_circle")
circle.calcArea(4);
circle.calcDiameter(4);
circle.calsCircumference(4);

var rectangle = require("./module_4_rectangle")
rectangle.calArea(2,4);
rectangle.calPerimeter(2,4);

var triangle = require("./module_4_triangle")
triangle.calcPerimeter(2,3,4);
triangle.isEquilateral(2,2,2);
triangle.isEquilateral(2,3,2);