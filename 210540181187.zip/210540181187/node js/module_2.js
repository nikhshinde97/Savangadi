/*2) Create a user defined local module calc.js that exposes the following functions: add(a,b), subtract(a,b),
multiply(a,b), divide(a,b), square(a), sum(a,b,c…)
Create a client application that invokes each of these methods
*/

exports. add = function(a,b){

    var add = a+b;
    console.log("sum of " + a+ " and " + b + " is: " + add );
}

exports.substract= function(a,b){

    var sub = a-b;
    console.log("substraction of " + a+ " and " + b + " is: " + sub);
}

exports.multiply= function(a,b){

    var mul = a*b;
    console.log("multiplication of " + a+ " and " + b + " is: " + mul);
}

exports.divide= function(a,b){

    var div = a/b;
    console.log("division of " + a+ " and " + b + " is: " + div);
}

exports.square= function(a){

    var sqr = a*a;
    console.log("square of " + a+ " is: " + sqr);
}

exports. sum = function(){
     arguments
     var sum = 0;
    for(i=0; i<arguments.length; i++)
    {
        sum=sum+arguments[i];
    }
        return sum;
    
    //console.log("sum of numbers is:" + sum );
    
}