/*4) Create 3 user defined modules that deal with shapes: circle.js, rectangle.js, triangle.js
 Circle.js has functions like : calcArea(radius), calcCircumference(radius), calcDiameter(radius)
 Rectangle.js – calcArea(length, breadth), calcPerimeter(length, breadth)
 Triangle.js – isEquilateral(side1, side2, side3), calcPerimeter()
Make use of Math predefined core object. Create a client application that invokes each of these methods
*/

//RECTANGLE

exports.calArea = function(length, breadth){

    var area = length*breadth;
    console.log("area of rectangle is: "+ area);
}

exports.calPerimeter = function(length, breadth){

    var perimeter = 2*(length+breadth);
    console.log("perimeter of rectangle is: "+ perimeter);
}