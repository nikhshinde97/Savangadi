/*3) Create a module by name mymodule.js to store three functions
 factorial – to find factorial of a number.
 myprime - Check prime number
 printable – to display table of a number
*/

exports.factorial = function(num){

    factorial=1;
    for(i=1; i<=num; i++ )
    {
        factorial=factorial*i;
    }
    console.log("factorial of "+ num+ " is " + factorial);
}

exports.prime = function(num){

    for(i=2; i<num; i++)
    {
        if(num%i==0)
        {
            console.log(num + " not a prime number");
            break;
        }
    }
    
    if(num==i)
    {
        console.log(num+" is a prime number");
    }
}

exports.printable = function(num)
{
    for(i=1; i<=10; i++)
    {
        console.log(num+" multiply " + i + " = " + num*i);
    }
}