//6) Create an array of names. Read the contents of array and save into a file – names.txt as a string
//delimited with | (pipe)

var fs = require ("fs");
var arr = ["chandana" , "darshana" , "nikhil" , "rohit" , "sarthak"];
fs.writeFile("names.txt" , arr.join('|') , function(err){
    if(err)
    console.log(err);
    else
    console.log("successful!!!");
});

//console.log(fs.readFileSync('names.txt').toString())