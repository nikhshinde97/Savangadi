var cal = require ("./module_2")
cal.add(4,5);
cal.substract(5,2);
cal.multiply(5,4);
cal.divide(25,5);
cal.square(5);
console.log("sum of numbers is: " +cal.sum(35,45,65,12));