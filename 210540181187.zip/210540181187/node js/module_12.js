/*12) Create a simple text file. Now use node file handling to read each line from text file, prefix line with a
number and display.
*/

var fs = require("fs");

fs.writeFile("emp1.txt" , "1001:Harry :Sales :23000"+'\n' , function(err){});
fs.appendFile("emp1.txt" , "1002:Sarita :Accounts :20000"+'\n' , function(err){});
fs.appendFile("emp1.txt" , "1003:Monika:TechSupport:35000" , function(err){});



var r = fs.readFile("emp1.txt", function(err, data){
    if(err)
    {
        console.log(err)
    }
    else
    v=data.toString();
    v=v.split("\n");
    for(i=0; i<3;i++)
    {
        a=v[i].split(":")
        console.log(i+1+ " " +a);
    }
});