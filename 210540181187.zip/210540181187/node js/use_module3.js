var check = require ("./module_3")
check.factorial(5);
check.prime(6);
check.prime(2);
check.prime(7);
check.printable(9);