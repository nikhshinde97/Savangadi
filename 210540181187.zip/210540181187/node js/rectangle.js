exports.calArea = function(length, breadth){

    var area = length*breadth;
    return("area of rectangle is: "+ area);
}

exports.calPerimeter = function(length, breadth){

    var perimeter = 2*(length+breadth);
    return("perimeter of rectangle is: "+ perimeter);
}