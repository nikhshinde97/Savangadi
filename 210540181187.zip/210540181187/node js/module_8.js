/*8) Consider an array that holds 4 employee objects. Emp details could be empid, empname and salary.
Loop thru this Employee array and store the employee objects in a text file using same format as in s
previous assignment.
*/

var emp1 = {empid: 101 , empname:"arjun" , salary:23000}
//var json1 = JSON.stringify(emp1);

var emp2 = {empid: 102 , empname:"radhika" , salary:25000}
//var json2 = JSON.stringify(emp2);

var emp3 = {empid: 103 , empname:"shivani" , salary:20000}
//var json3 = JSON.stringify(emp3);

var emp4 = {empid: 104 , empname:"shiva" , salary:27000}
//var json4 = JSON.stringify(emp4);

var str="";
var arr = [];
arr.push(emp1, emp2, emp3, emp4)
arr.forEach(function(i)
{
    str=str+i.empid+":"+i.empname+":"+i.salary+'\n'
})
var fs = require("fs");
//for(i in arr)
fs.appendFile("emp2.txt" , str , function(){});
