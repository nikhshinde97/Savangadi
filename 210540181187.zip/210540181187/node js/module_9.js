/*9) Assume a customer.json that has customer details like customer name, address, ph no, credit-rating
etc. Read this file, parse the json and display all customer names along with their contact details
*/

var customer1 = {customer_name: "chandana" , address:"101, pune, maharashtra" ,
phone_number:987654321, credit_rating:"*****" ,
email:"chandana@gmail.com"};
var json1 = JSON.stringify(customer1);

var customer2 = {customer_name: "shivani" , address:"102, pune, maharashtra" ,
phone_number:9889546258, credit_rating:"****" ,
email:"shivani@gmail.com"};
var json2 = JSON.stringify(customer2);

var customer3 = {customer_name: "AmanVyas" , address:"103, pune, maharashtra" ,
phone_number:9825874896, credit_rating:"*****" ,
email:"av@gmail.com"};
var json3 = JSON.stringify(customer3);


var fs = require("fs");
fs.readFile("cust.json"  ,  function(err, data){

    if(err)
    console.log(err)

    else
    {
        let obj = JSON.parse(data.toString());
        let customers = obj.customer;

        for(c of customers)
        {
            console.log(c.customer_name+ " "+ c.phone_number);
        }

    }
});