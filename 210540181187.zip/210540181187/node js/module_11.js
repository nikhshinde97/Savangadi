/*11) Consider a json object that describes a book with bookid, name, author and price. Convert this json
object into string and save into a file book.txt
*/

var book = {bookid: 1001 , name:"node.js" , author:"Sandro Pasquali" , price:3000}
var json = JSON.stringify(book);

var fs = require("fs")
fs.writeFile("book.txt" , json, function(err){
    if(err)
    console.log(err)
});