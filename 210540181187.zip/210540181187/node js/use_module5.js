var check = require("./module_5")
check.palindrome("madam");
check.palindrome("ram");
check.search();
check.upper("chandana");