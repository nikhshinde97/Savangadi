/*1) Create a user defined local module greet.js containing a function greet() that greets user based on time
of the day. If its morning, greet user as “Good morning”, if its afternoon, greet user as “Good
Afternoon” else as “Good Evening”
Create a client module that will bring in the greet.js module and invoke the greet function*/

exports.greet = function(name){
var d1= new Date();
var hour= d1.getHours();

if(hour<11)
{
console.log("Good Morning " + name);
}

else if(hour<16)
{
console.log("Good Afternoon " + name);
}

else{
console.log("Good Evening " + name);
}
}