/*5) Create a user defined module that deals with strings: This module will have the following functions:
 palindrome(string ) : accepts a strings and checks if it is palindrome
 upper(string) : converts given string to uppercase
 search() : Say, have an array that holds many web site names. Eg, www.google.com,
www.msn.com, www.amazon.co.in, in.answers.yahoo.com, en.m.wikipedia.com,
codehs.gitbooks.io, www.coderanch.com etc. Search for all sites that begin with “www” and
display the total number of such sites. Eg for above eg, total is 4
Create a client application that invokes each of these methods
*/

exports.palindrome = function(string){

    let j = string.length -1;
    for(i=0; i<j/2; i++)
    {
        x= string[i];
        y= string[j-i];

        if(x!=y)
        return  console.log(string +" is not palindrome");
    }

    return console.log(string +" is palindrome");
}

exports.upper = function(string){

    console.log(string.toUpperCase());
}

exports.search = function(){
var array= new Array("www.google.com", "www.msn.com", "www.amazon.co.in", 
"in.answers.yahoo.com" , "en.m.wikipedia.com" , "codehs.gitbooks.io", 
"www.coderanch.com");
var count=0;
for(i=0;i<=6;i++)
{
var a = array[i];
a = a.search("www");
if(a==0)
{
count=count+1;
}
}
console.log(count);
}