/*4) Create 3 user defined modules that deal with shapes: circle.js, rectangle.js, triangle.js
 Circle.js has functions like : calcArea(radius), calcCircumference(radius), calcDiameter(radius)
 Rectangle.js – calcArea(length, breadth), calcPerimeter(length, breadth)
 Triangle.js – isEquilateral(side1, side2, side3), calcPerimeter()
Make use of Math predefined core object. Create a client application that invokes each of these methods
*/

//CIRCLE

exports.calcArea = function(radius){

    var area = Math.PI*radius*radius;
    console.log("area of circle is: " + area);
}

exports.calsCircumference = function(radius){

    var cum = 2*Math.PI*radius;
    console.log("circumference of circle is: " + cum);
}

exports.calcDiameter = function(radius){

    var dia = 2*radius;
    console.log("diameter of circle is: " + dia);
}