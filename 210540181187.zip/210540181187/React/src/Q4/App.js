import React, { Component } from 'react';
import FirstName from './FirstName';
import LastName from './LastName';


class App extends Component {
     state ={ 
        newsHeader :"ANIL,Patil"
       
}
    render() {
        let c = this.state.newsHeader.split(",")
        c = c.join
        
       let v = c.split(",")       
        return (
            <div>
               <FirstName id={v[0]}/>
               <LastName id={v[1]}/>              
            </div>
        );
    }

}
export default App;