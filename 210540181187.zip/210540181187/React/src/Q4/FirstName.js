import React from 'react';



const FirstName = (props) =>{
 return(
   <p>First Name : {props.id}</p>       
 )
}

export default FirstName;