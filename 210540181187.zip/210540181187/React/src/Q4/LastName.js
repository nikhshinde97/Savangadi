import React from 'react';



const LastName= (props) =>{
 return(
   <p>Last Name : {props.id}</p>       
 )
}

export default LastName;