import React, {Component} from 'react';
import NewsContent from './NewsContent';
import NewsHeader from "./NewsHeader";

//import NewsContent from "./NewsContent";
class App extends Component{

    state ={  
        
            newsHeader :"ANIL,Patil"
           
    }
    render(){
        return(
            var v = this.state.newsHeader.split(",")
           <div> 
            <NewsHeader head={this.state.newsHeader}/>
            
           </div>
        );
    }

}
export default App;