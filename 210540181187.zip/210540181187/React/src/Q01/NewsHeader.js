import reactDom from "react-dom";
import React from 'react';

const NewsHeader = (props) => {
    return(

        <h1> {props.head} </h1>
    )
}
export default NewsHeader;