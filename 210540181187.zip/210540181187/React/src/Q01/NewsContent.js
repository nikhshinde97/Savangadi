import reactDom from "react-dom";
import React from 'react';

const NewsContent = (props) => {
    return(

        <p> {props.content} </p>
    )
}
export default NewsContent;