import reactDom from "react-dom";
import React from 'react';

const person = (props) => {
    
   
    return(
        <div>
      
      <p onClick={props.click}>  youre {props.name} & your {props.age} year old  </p>
        </div>
        )
}
export default person;
 {/* <p> youre {props.name} & your {props.age} year old  </p>
        {squ}
       
        */ }
   {/* <div>
        <p onMouseMove={props.click}>hie {props.sname} you are {props.age} year old</p>
        {props.children}

        <input type="text"
               onchange={props.chnage}
               value={props.name} />     

        </div> */ }