import React, {Component} from 'react';

class ToDOComponent extends Component{

 state = {
     person : [],
  showPerson : ""
   // a : false
 } 

 handleChyange=(e)=>{
    
    this.setState({showPerson: e.target.value})
    
 }
 
 deletePersonHandler = (perIndex)=>{
    let per = this.state.person;
    per.splice(perIndex,1)
    this.setState({person:per})
  }
 
  addListHandler=() => {
  // let c = [...this.state.person,this.state.showPerson]
    //var c = this.state.person
  // console.log(c)
    //var b={ id: parseInt(c.length*Math.random()), list : document.getElementById("n1").value }
    
    this.setState({person:[...this.state.person,this.state.showPerson]})
     this.setState({showPerson:""})
  //  document.getElementById("n1").value = ""
    
}


render() {

   const list = this.state.person.map((ele,index)=>{
        return( <li onClick = {()=> this.deletePersonHandler(index)} >{ele}</li>)
    })
 
    return(
        <div>
        <input type="text"  id="n1" onChange={this.handleChyange} value={this.state.showPerson}/>
        <input type="button" onClick={this.addListHandler} value="Add to list" />
        <ol>
            {list}
        </ol>
    </div>
    )

}
}

export default ToDOComponent;