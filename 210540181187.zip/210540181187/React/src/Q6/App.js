import React, {Component} from 'react';


import ToDoComponent from './ToDoComponent';


class App extends Component {
    render() {
        return(
            <ToDoComponent />
        )
    }
}
export default App;