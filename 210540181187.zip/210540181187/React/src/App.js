import React, {Component} from 'react';
import logo from './logo.svg';
import './App.css';
import Person from './Person/Person'
import NameChangeComponent from './NameChangeComponent';
//import StatefulComponent from './StatefulCompnent/StatefulComponent';

class App extends Component {

  state = {
    person : [
      {name : "Nikhil1", age : 24 },
      {name : "Swati1", age : 25 },
      {name : "Shrilata1", age : 23 },
    ], 
    sPerson : false,
    
  }

  togglePersonHandler = () => {
        const doesshow = this.state.sPerson;
        this.setState({sPerson : !doesshow});
  }

  deletePersonHandler = (perIndex)=>{
    let per = this.state.person;
    per.splice(perIndex,1)
    this.setState({person:per})
  }
  render() {
    const var1 = this.state.person.map((ele,index) => {
                                                return (
                                                <Person 
                                                click={()=> this.deletePersonHandler(index)}    
                                                name={ele.name}
                                                    age={ele.age} />
                                                )
                                      })
    
  let person =""
  if(this.state.sPerson){
    person = var1
  }
  
  var arr = [1,2,3,4,5,6]
  var newArr =  arr.map(function(ele){
        return <li>{ele*ele}</li>    
  })



  return (
      
     <div>
    <h1>Welcomen to React </h1>
    <input type="button" onClick={this.togglePersonHandler} value="Toggle Person" />

   {person}
     </div>
   )
   {/*      
            
    */} 
      
{/*








state = {
  name : "",
 person : [
    {name : "Nikhil1", age : 24 },
    {name : "Swati1", age : 25 },
    {name : "Shrilata1", age : 23 },
  ]
}

btnHandler = (...newName) =>{
  this.setState({
    person : [
      {name : newName[0], age : 24 },
      {name : newName[1], age : 25 },
      {name : newName[2], age : 23 },
    ]
  })
}
}
inputHandler =(event) => {
    this.setState({name:event.target.value})
}

nameChangeHandler =(event)=> {
  this.setState({
    person : [{name:event.target.value},
    {name : "Swati1", age : 25 },
    {name : "Shrilata1", age : 23 },
    ]
  })
}  



  render() {
  
  return(
  <div className="App">
    <h1>Hi, Welcome to React....!!</h1>
    
    
    <button onMouseMove={this.btnHandler.bind(this,"dukkar","chuman","anChuman")}>Switch Names</button>
    
     
    <Person sname={this.state.person[0].name} 
              age={this.state.person[0].age}
               />
    <Person sname={this.state.person[1].name} 
                    age={this.state.person[1].age} 
                    click = {()=>this.btnHandler("anChuman","chuman","dukkar")}>
                    Hobbies : monitoring 
                    </Person>
    <Person sname={this.state.person[2].name} age={this.state.person[2].age}> Hobbies : teaching </Person>
     <NameChangeComponent name={this.state.name}  changeName={this.nameChangeHandler}/>

  
  </div> 
    );
  }
  }

*/}

}


}
export default App;
