import React, {Component} from 'react';
import SkillListComponent from "./SkillListComponent"


class App extends Component {
    render() {
        return(
            <SkillListComponent>
                <p>NodeJS</p>
                <p>ReactJS</p>
                <p>Angular 10</p>
                <p>Mongo DB</p>
            </SkillListComponent>
        )
    }
}
export default App;