import React, {Component} from 'react';
import reactDom from "react-dom";


class SkillListComponent extends Component {
    render() {
        let skill = this.props.children
   let printSkill = skill.map(ele =>{
       return <li>{ele}</li>
   }) 
        return(
            <ol>
                {printSkill}
            </ol>
        )
{/* const SkillListComponent = (props) => {
    let skill = props.children
   let printSkill = skill.map(ele =>{
       return <li>{ele}</li>
   }) 
   return(
    <ol>
        {printSkill}
    </ol>
)
}*/ }
    }

}

export default SkillListComponent;