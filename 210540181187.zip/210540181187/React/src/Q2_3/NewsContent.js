import reactDom from "react-dom";
import React from 'react';
import "./NewsContent.css"

const NewsContent = (props) => {
    return(
        <div className="div">
        <h2 className="h"> {props.head} </h2>
       <p className="p"> {props.content} </p>
       
        </div>
    )
}
export default NewsContent;