import reactDom from "react-dom";
import React from 'react';
import "./NewsContent.css"

const NewsHeader = (props) => {
    return(
        <h1 className="newsHeader"> Welcome to Nikhil Times </h1>
    )
}
export default NewsHeader;