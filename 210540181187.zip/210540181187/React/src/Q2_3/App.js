import React, {Component} from 'react';
import NewsContent from './NewsContent';
import NewsHeader from "./NewsHeader";
import "./App.css"
//import NewsContent from "./NewsContent";
class App extends Component{

    state ={ news : [
        {
            newsHeader :"Maharashtra's Covid deaths now 10th highest in the world",
            newsContent : "On June 6, Maharashtra recorded more than one lakh Covid dOn June 6,Maharashtra recorded more than one lakh Covid deaths. With 233 new deaths, the state’s death toll crossed 1,00,130, while the death rate stood at 1.72 per cent. The total fatalities in the state now accounts for 29 per cent of reported coronavirus deaths in India. It is also over three times higher than Karnataka (31,580),which has the second highest death count in the CountQueuingStrategy.",
            
        },
        {
            newsHeader :"Daily Covid cases fall below 1 lakh after 63 days, recovery rate improves to 94.29%",
            newsContent : "India on Tuesday registered 86,498 fresh Covid-19 cases, the lowest in over two months, pushing the country's recovery rate to 94.29 per cent.\r\n\
            India has reported the lowest Covid cases in 66 days, and less than one lakh Covid cases after 63 days.India's active caseload has further declined to 13,03,702,\r\n\
            a decrease of 97,907 in the past 24 hours. After over 1.82 lakh patients' recovery in the past 24 hours, the total recoveries have climbed to 2,73,41,462.Notably, \r\n\
            the recoveries have continued to outnumber the daily Covid cases for the 26th consecutive day. \r\n\
            While the weekly positivity rate currently stands at 5.94 per cent, the daily positivity rate has dropped to 4.62 per cent, less than 10 per cent for 15 consecutive days.\r\n\
            India also saw 2,123 deaths in the past 24 hours, as per the Union health ministry, taking the death toll in the country to 3,51,309. The testing capacity has been substantially ramped up. \r\n\
            A total of 18,73,485 samples were tested in the past 24 hours."
        },

        {
            newsHeader :"Narendra Modi speech highlights: PM announces free vaccine for all 18+, Oppn says ‘thanks for acceding to our request’",
            newsContent : "PM Narendra Modi address to nation highlights: In his address to the nation, Prime Minister Narendra Modi Monday announced a centralised Covid-19 vaccine policy. “Twenty-five per cent of the vaccination work with states will now be handled by the Centre, it will be implemented in the coming two weeks. Both State and Centre will work as per new guidelines in the coming two weeks,” Modi said.\r\n\
            He also announced that from June 21, all citizens above the age of 18 years will get free vaccines, and asserted that vaccine supply would be increased significantly in the country in the coming days. “Work on producing an intranasal vaccine for Covid is also happening,” he said.\r\n\
            The Prime Minister’s address to the nation comes on a day India reported 1,00,636 new Covid-19 cases and 2,427 deaths, the lowest in 61 days. Part of it has to do with low testing on Sunday. Only 15.87 lakh samples were tested on Sunday, compared to an average of more than 20 lakh in the last week."
        
        }
    ]
    }
    btnHandler =() =>{
        this.setState(this.state.news[2]=this.state.news[0])

    }
    render(){
        return(
            <div className="div1"> 
           
            
            <NewsHeader />
            <button onClick={this.btnHandler}>Next News</button>
            <NewsContent head={this.state.news[2].newsHeader} content={this.state.news[2].newsContent}/>
            
           </div>
        );
    }

}
export default App;