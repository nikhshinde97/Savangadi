import React, {Component} from 'react';
//here we are importing the react and component as we are creating class
class StatefulComponent extends Component{
     state = {
         name : "Nikhil",
         email : "nikh.shinde97@yahoo.com",
         addres : "Aurangabad"    
         }
    render(){
        return(
            <div>
                <h3>Name : {this.state.name} </h3>
                <h3>Email : {this.state.email} </h3>
                <h3>Address : {this.state.addres} </h3>
            </div>
        )
    }
}
 export default StatefulComponent;