import React, {Component} from 'react';


class NameChangeComponent extends Component {
    render(props) {
    return(
        <div>
            Name <input type="text" value={this.props.name} onChange={this.props.changeName} />
            hello this is {this.props.name}
        </div>
    )
    }
}



export default NameChangeComponent