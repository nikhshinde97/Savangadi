var dist = parseInt(prompt("enter distance in inches"));
document.write("distance in cm is:" + (dist*2.54) + "cm");